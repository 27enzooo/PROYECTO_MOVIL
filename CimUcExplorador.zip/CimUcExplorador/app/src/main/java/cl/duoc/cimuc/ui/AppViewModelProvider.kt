package cl.duoc.cimuc.ui

import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import cl.duoc.cimuc.CimApplication
import cl.duoc.cimuc.ui.screens.busqueda.BusquedaViewModel
import cl.duoc.cimuc.ui.screens.contacto.ContactoViewModel
import cl.duoc.cimuc.ui.screens.detalle.DetalleViewModel
import cl.duoc.cimuc.ui.screens.inicio.InicioViewModel
import cl.duoc.cimuc.ui.screens.ruta.RutaViewModel

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer { InicioViewModel(cimApplication().repository) }
        initializer { BusquedaViewModel(createSavedStateHandle(), cimApplication().repository) }
        initializer { DetalleViewModel(createSavedStateHandle(), cimApplication().repository) }
        initializer { RutaViewModel(createSavedStateHandle(), cimApplication().repository) }
        initializer { ContactoViewModel(createSavedStateHandle(), cimApplication().repository) }
    }
}

private fun CreationExtras.cimApplication(): CimApplication =
    this[APPLICATION_KEY] as CimApplication
