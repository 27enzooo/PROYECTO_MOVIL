@file:OptIn(ExperimentalMaterial3Api::class)

package cl.duoc.cimuc.ui.screens.ruta

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.duoc.cimuc.data.model.PasoRuta
import cl.duoc.cimuc.ui.components.AparicionEscalonada
import cl.duoc.cimuc.ui.components.BarraSuperior
import cl.duoc.cimuc.ui.components.BotonPrincipal
import cl.duoc.cimuc.ui.components.TarjetaContenido

@Composable
fun PantallaRuta(
    viewModel: RutaViewModel,
    onVolver: () -> Unit,
    onAbrir: (Int) -> Unit,
    onColaborar: (Int) -> Unit
) {
    val ruta by viewModel.ruta.collectAsStateWithLifecycle()
    val actual = ruta

    Scaffold(topBar = { BarraSuperior("Ruta de Innovación", onVolver) }) { padding ->
        if (actual == null) {
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val idOrigen = actual.origen.idContenido
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Ruta desde: ${actual.origen.titulo}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                actual.pasos.forEachIndexed { indice, paso ->
                    AparicionEscalonada(indice) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TarjetaPaso(
                                paso = paso,
                                onClick = {
                                    if (paso.esOportunidad) onColaborar(idOrigen)
                                    else paso.idContenido?.let(onAbrir)
                                }
                            )
                            if (indice < actual.pasos.lastIndex) {
                                Icon(
                                    imageVector = Icons.Filled.ArrowDownward,
                                    contentDescription = "Siguiente paso",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                actual.siguiente?.let { siguiente ->
                    BotonPrincipal(
                        texto = "Explorar siguiente",
                        onClick = {
                            if (siguiente.esOportunidad) onColaborar(idOrigen)
                            else siguiente.idContenido?.let(onAbrir)
                        }
                    )
                }

                if (actual.relacionados.isNotEmpty()) {
                    Text(
                        text = "Contenidos relacionados",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    actual.relacionados.forEach { relacionado ->
                        TarjetaContenido(
                            contenido = relacionado,
                            onClick = { onAbrir(relacionado.idContenido) }
                        )
                    }
                }

                Box(modifier = Modifier.padding(bottom = 16.dp))
            }
        }
    }
}

@Composable
private fun TarjetaPaso(paso: PasoRuta, onClick: () -> Unit) {
    val color = when {
        paso.esActual -> MaterialTheme.colorScheme.primaryContainer
        paso.esOportunidad -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Card(
        onClick = onClick,
        enabled = paso.titulo != null && !paso.esActual,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = color,
            disabledContainerColor = color
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = if (paso.esActual) "${paso.etiqueta} · ESTÁS AQUÍ" else paso.etiqueta,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            if (paso.titulo != null) {
                Text(
                    text = paso.titulo,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (paso.detalle != null) {
                    Text(
                        text = paso.detalle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    text = "Sin elemento relacionado en los datos de prueba",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
