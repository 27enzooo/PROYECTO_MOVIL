package cl.duoc.cimuc.data.local

import cl.duoc.cimuc.data.model.TipoContenido.ACTIVIDAD
import cl.duoc.cimuc.data.model.TipoContenido.CAPACIDAD
import cl.duoc.cimuc.data.model.TipoContenido.INTEGRANTE
import cl.duoc.cimuc.data.model.TipoContenido.PROYECTO
import cl.duoc.cimuc.data.model.TipoContenido.PUBLICACION

/** Catálogo ficticio (RA-07): ningún dato corresponde a información real de CIM UC. */
object DatosIniciales {

    val contenidos = listOf(
        Contenido(1, "Vivienda Modular de Madera", "Prototipo de vivienda modular prefabricada en madera, pensada para reducir tiempos de construcción en zonas de difícil acceso.", PROYECTO, "Construcción", 2026, "Activo", "Imagen referencial de vivienda modular"),
        Contenido(2, "Madera Laminada para Edificios Medianos", "Estudio de sistemas de madera laminada cruzada para edificios de mediana altura con foco en desempeño estructural.", PROYECTO, "Construcción", 2025, "Activo", "Imagen referencial de edificio en madera"),
        Contenido(3, "Biomasa Forestal para Energía Térmica", "Proyecto piloto para aprovechar residuos forestales como fuente de energía térmica en pequeñas industrias.", PROYECTO, "Bioenergía", 2025, "En evaluación", "Imagen referencial de biomasa forestal"),

        Contenido(4, "Ensayos Estructurales de Madera", "Capacidad de laboratorio para ensayar resistencia y rigidez de elementos y uniones de madera.", CAPACIDAD, "Construcción", 2024, "Disponible", "Imagen referencial de laboratorio de ensayos"),
        Contenido(5, "Diseño Paramétrico con Madera", "Capacidad de diseño computacional para generar geometrías optimizadas fabricables en madera.", CAPACIDAD, "Diseño y Arquitectura", 2025, "Disponible", "Imagen referencial de diseño paramétrico"),
        Contenido(6, "Caracterización de Biomasa", "Capacidad de análisis para medir poder calorífico y humedad de biomasa de origen forestal.", CAPACIDAD, "Bioenergía", 2024, "Disponible", "Imagen referencial de análisis de biomasa"),

        Contenido(7, "Dra. Camila Rojas", "Investigadora principal. Especialidad: ingeniería estructural en madera.", INTEGRANTE, "Construcción", 2020, "Activa", "Imagen referencial de integrante"),
        Contenido(8, "Dr. Tomás Valenzuela", "Investigador. Especialidad: diseño computacional y fabricación digital.", INTEGRANTE, "Diseño y Arquitectura", 2021, "Activo", "Imagen referencial de integrante"),
        Contenido(9, "Ing. Fernanda Soto", "Coordinadora de proyectos. Especialidad: bioenergía y gestión de residuos forestales.", INTEGRANTE, "Bioenergía", 2022, "Activa", "Imagen referencial de integrante"),

        Contenido(10, "Guía de Diseño de Uniones en Madera", "Publicación técnica con recomendaciones para el diseño de uniones en estructuras de madera.", PUBLICACION, "Construcción", 2025, "Publicado", "Imagen referencial de publicación"),
        Contenido(11, "Informe Técnico de Pellets de Madera", "Informe sobre calidad y desempeño de pellets elaborados con residuos de aserradero.", PUBLICACION, "Bioenergía", 2024, "Publicado", "Imagen referencial de publicación"),

        Contenido(12, "Taller de Construcción en Madera", "Taller práctico para conocer sistemas constructivos en madera y sus aplicaciones.", ACTIVIDAD, "Construcción", 2026, "Programada", "Imagen referencial de taller"),
        Contenido(13, "Seminario de Innovación Forestal", "Seminario abierto sobre innovación, sustentabilidad y oportunidades en el sector forestal.", ACTIVIDAD, "Sustentabilidad", 2026, "Programada", "Imagen referencial de seminario")
    )

    val relaciones = listOf(
        Relacion(contenidoOrigen = 1, contenidoDestino = 4, tipoRelacion = "utiliza capacidad"),
        Relacion(contenidoOrigen = 1, contenidoDestino = 5, tipoRelacion = "utiliza capacidad"),
        Relacion(contenidoOrigen = 1, contenidoDestino = 7, tipoRelacion = "integrante del proyecto"),
        Relacion(contenidoOrigen = 1, contenidoDestino = 8, tipoRelacion = "integrante del proyecto"),
        Relacion(contenidoOrigen = 1, contenidoDestino = 10, tipoRelacion = "documentado en"),
        Relacion(contenidoOrigen = 1, contenidoDestino = 12, tipoRelacion = "difundido en"),
        Relacion(contenidoOrigen = 2, contenidoDestino = 4, tipoRelacion = "utiliza capacidad"),
        Relacion(contenidoOrigen = 2, contenidoDestino = 7, tipoRelacion = "integrante del proyecto"),
        Relacion(contenidoOrigen = 2, contenidoDestino = 10, tipoRelacion = "documentado en"),
        Relacion(contenidoOrigen = 3, contenidoDestino = 6, tipoRelacion = "utiliza capacidad"),
        Relacion(contenidoOrigen = 3, contenidoDestino = 9, tipoRelacion = "integrante del proyecto"),
        Relacion(contenidoOrigen = 3, contenidoDestino = 11, tipoRelacion = "documentado en"),
        Relacion(contenidoOrigen = 3, contenidoDestino = 13, tipoRelacion = "difundido en"),
        Relacion(contenidoOrigen = 4, contenidoDestino = 7, tipoRelacion = "a cargo de"),
        Relacion(contenidoOrigen = 5, contenidoDestino = 8, tipoRelacion = "a cargo de"),
        Relacion(contenidoOrigen = 6, contenidoDestino = 9, tipoRelacion = "a cargo de")
    )

    val oportunidades = listOf(
        Oportunidad(1, "Piloto de vivienda modular con socios constructores", "Buscamos empresas constructoras interesadas en construir y evaluar un piloto de vivienda modular.", "contacto.simulado@cimuc.example", 1),
        Oportunidad(2, "Proyecto conjunto de ensayos para edificios de mediana altura", "Oportunidad de colaborar en ensayos de sistemas de madera laminada con apoyo del laboratorio.", "contacto.simulado@cimuc.example", 2),
        Oportunidad(3, "Alianza para valorizar residuos forestales", "Invitamos a industrias a participar en el piloto de energía térmica con biomasa.", "contacto.simulado@cimuc.example", 3),
        Oportunidad(4, "Servicio de ensayos estructurales para empresas", "Las empresas pueden solicitar ensayos de uniones y elementos de madera.", "contacto.simulado@cimuc.example", 4),
        Oportunidad(5, "Co-diseño de prototipos paramétricos", "Espacio para desarrollar prototipos en madera junto a estudios de diseño y arquitectura.", "contacto.simulado@cimuc.example", 5),
        Oportunidad(6, "Estudios de caracterización de biomasa", "Las organizaciones pueden solicitar análisis de su biomasa para evaluar su uso energético.", "contacto.simulado@cimuc.example", 6)
    )
}
