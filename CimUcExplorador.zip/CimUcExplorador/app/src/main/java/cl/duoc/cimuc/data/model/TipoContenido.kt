package cl.duoc.cimuc.data.model

enum class TipoContenido(val plural: String, val singular: String) {
    PROYECTO("Proyectos", "Proyecto"),
    CAPACIDAD("Capacidades I+D", "Capacidad I+D"),
    INTEGRANTE("Integrantes", "Integrante"),
    PUBLICACION("Publicaciones", "Publicación"),
    ACTIVIDAD("Actividades", "Actividad")
}
