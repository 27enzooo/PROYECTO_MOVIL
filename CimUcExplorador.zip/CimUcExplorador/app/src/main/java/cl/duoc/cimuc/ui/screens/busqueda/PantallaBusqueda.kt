package cl.duoc.cimuc.ui.screens.busqueda

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.duoc.cimuc.data.model.TipoContenido
import cl.duoc.cimuc.ui.components.BarraSuperior
import cl.duoc.cimuc.ui.components.SelectorFiltro
import cl.duoc.cimuc.ui.components.TarjetaContenido

@Composable
fun PantallaBusqueda(
    viewModel: BusquedaViewModel,
    onVolver: () -> Unit,
    onAbrir: (Int) -> Unit
) {
    val filtros by viewModel.filtros.collectAsStateWithLifecycle()
    val areas by viewModel.areas.collectAsStateWithLifecycle()
    val resultados by viewModel.resultados.collectAsStateWithLifecycle()

    val opcionesTipo = listOf("Todos") + TipoContenido.entries.map { it.plural }
    val opcionesArea = listOf("Todas") + areas

    Scaffold(topBar = { BarraSuperior("Explorar", onVolver) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = filtros.texto,
                onValueChange = viewModel::onTextoChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Buscar por título o descripción") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (filtros.texto.isNotEmpty()) {
                        IconButton(onClick = { viewModel.onTextoChange("") }) {
                            Icon(Icons.Filled.Clear, contentDescription = "Borrar búsqueda")
                        }
                    }
                }
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SelectorFiltro(
                    etiqueta = "Tipo",
                    seleccion = filtros.tipo?.plural ?: "Todos",
                    opciones = opcionesTipo,
                    onSeleccion = { indice ->
                        viewModel.onTipoChange(if (indice == 0) null else TipoContenido.entries[indice - 1])
                    },
                    modifier = Modifier.weight(1f)
                )
                SelectorFiltro(
                    etiqueta = "Área",
                    seleccion = filtros.area ?: "Todas",
                    opciones = opcionesArea,
                    onSeleccion = { indice ->
                        viewModel.onAreaChange(if (indice == 0) null else opcionesArea[indice])
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = if (resultados.size == 1) "1 resultado" else "${resultados.size} resultados",
                style = MaterialTheme.typography.titleSmall
            )

            if (resultados.isEmpty()) {
                Text(
                    text = "No hay contenidos que coincidan con la búsqueda.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(resultados, key = { it.idContenido }) { contenido ->
                    TarjetaContenido(
                        contenido = contenido,
                        onClick = { onAbrir(contenido.idContenido) },
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }
    }
}
