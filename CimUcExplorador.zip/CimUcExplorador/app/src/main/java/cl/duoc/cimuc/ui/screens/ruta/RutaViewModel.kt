package cl.duoc.cimuc.ui.screens.ruta

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.duoc.cimuc.data.model.RutaInnovacion
import cl.duoc.cimuc.data.repository.ContenidoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RutaViewModel(
    savedStateHandle: SavedStateHandle,
    repositorio: ContenidoRepository
) : ViewModel() {

    private val id: Int = checkNotNull(savedStateHandle["id"])

    private val _ruta = MutableStateFlow<RutaInnovacion?>(null)
    val ruta: StateFlow<RutaInnovacion?> = _ruta.asStateFlow()

    init {
        viewModelScope.launch { _ruta.value = repositorio.construirRuta(id) }
    }
}
