package cl.duoc.cimuc.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Esquema = lightColorScheme(
    primary = Color(0xFF6D4C2F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF2E0CC),
    onPrimaryContainer = Color(0xFF2B1706),
    secondary = Color(0xFF3F6B4B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCDE8D3),
    onSecondaryContainer = Color(0xFF0B2514),
    background = Color(0xFFFFFBF7),
    onBackground = Color(0xFF1F1B16),
    surface = Color(0xFFFFFBF7),
    onSurface = Color(0xFF1F1B16),
    surfaceVariant = Color(0xFFF1E7DD),
    onSurfaceVariant = Color(0xFF51453A),
    error = Color(0xFFB3261E)
)

val ColorExito = Color(0xFF2E7D32)

@Composable
fun CimUcTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Esquema, content = content)
}
