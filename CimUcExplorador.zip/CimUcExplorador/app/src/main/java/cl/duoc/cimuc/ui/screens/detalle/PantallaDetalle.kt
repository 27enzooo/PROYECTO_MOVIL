@file:OptIn(ExperimentalMaterial3Api::class)

package cl.duoc.cimuc.ui.screens.detalle

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.duoc.cimuc.ui.components.BarraSuperior
import cl.duoc.cimuc.ui.components.BotonPrincipal
import cl.duoc.cimuc.ui.components.BotonSecundario
import cl.duoc.cimuc.ui.components.icono

@Composable
fun PantallaDetalle(
    viewModel: DetalleViewModel,
    onVolver: () -> Unit,
    onVerRuta: (Int) -> Unit,
    onColaborar: (Int) -> Unit,
    onAbrir: (Int) -> Unit
) {
    val contenido by viewModel.contenido.collectAsStateWithLifecycle()
    val relacionados by viewModel.relacionados.collectAsStateWithLifecycle()
    val actual = contenido

    Scaffold(
        topBar = { BarraSuperior(actual?.tipo?.singular ?: "Detalle", onVolver) }
    ) { padding ->
        if (actual == null) {
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .semantics { contentDescription = actual.imagen },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = actual.tipo.icono(),
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = actual.titulo,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text("Área: ${actual.area}", style = MaterialTheme.typography.bodyLarge)
                Text(
                    text = "Año: ${actual.anio} · Estado: ${actual.estado}",
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(actual.descripcion, style = MaterialTheme.typography.bodyMedium)

                if (relacionados.isNotEmpty()) {
                    Text(
                        text = "Relacionado con",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    relacionados.forEach { relacionado ->
                        AssistChip(
                            onClick = { onAbrir(relacionado.idContenido) },
                            label = { Text(relacionado.titulo) },
                            leadingIcon = {
                                Icon(
                                    imageVector = relacionado.tipo.icono(),
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                BotonPrincipal(
                    texto = "Ver Ruta de Innovación",
                    onClick = { onVerRuta(actual.idContenido) }
                )
                BotonSecundario(
                    texto = "Me interesa colaborar",
                    onClick = { onColaborar(actual.idContenido) }
                )
            }
        }
    }
}
