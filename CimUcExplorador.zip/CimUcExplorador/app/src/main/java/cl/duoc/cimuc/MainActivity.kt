package cl.duoc.cimuc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import cl.duoc.cimuc.ui.navigation.AppNavegacion
import cl.duoc.cimuc.ui.theme.CimUcTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CimUcTheme {
                AppNavegacion()
            }
        }
    }
}
