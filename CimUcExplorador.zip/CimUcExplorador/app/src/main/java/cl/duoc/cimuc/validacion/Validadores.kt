package cl.duoc.cimuc.validacion

/** Reglas de validación del formulario, independientes de la interfaz. Devuelven el mensaje de error o null. */
object Validadores {

    const val MAX_ORGANIZACION = 60
    const val MAX_MENSAJE = 300

    private val regexOrganizacion = Regex("^[\\p{L}0-9 .,&'\\-]+$")

    fun organizacion(valor: String): String? {
        val texto = valor.trim()
        return when {
            texto.isEmpty() -> "Ingresa el nombre de tu organización"
            texto.length < 3 -> "Debe tener al menos 3 caracteres"
            texto.length > MAX_ORGANIZACION -> "Máximo $MAX_ORGANIZACION caracteres"
            !regexOrganizacion.matches(texto) -> "Solo letras, números y . , & - '"
            else -> null
        }
    }

    fun mensaje(valor: String): String? {
        val texto = valor.trim()
        return when {
            texto.isEmpty() -> "Escribe un mensaje"
            texto.length < 10 -> "El mensaje debe tener al menos 10 caracteres"
            texto.length > MAX_MENSAJE -> "Máximo $MAX_MENSAJE caracteres"
            else -> null
        }
    }
}
