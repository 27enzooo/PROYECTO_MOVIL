@file:OptIn(ExperimentalMaterial3Api::class)

package cl.duoc.cimuc.ui.screens.inicio

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.duoc.cimuc.data.model.TipoContenido
import cl.duoc.cimuc.ui.components.TarjetaContenido
import cl.duoc.cimuc.ui.components.escalaAlPresionar
import cl.duoc.cimuc.ui.components.icono

@Composable
fun PantallaInicio(
    viewModel: InicioViewModel,
    onBuscar: () -> Unit,
    onCategoria: (TipoContenido) -> Unit,
    onAbrir: (Int) -> Unit
) {
    val historial by viewModel.historial.collectAsStateWithLifecycle()
    val categorias = listOf(
        TipoContenido.PROYECTO,
        TipoContenido.CAPACIDAD,
        TipoContenido.INTEGRANTE,
        TipoContenido.PUBLICACION
    )

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CIM UC",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedButton(onClick = onBuscar) {
                    Icon(Icons.Filled.Search, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Buscar")
                }
            }

            Text(
                text = "Explora innovación en madera",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            categorias.chunked(2).forEach { fila ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    fila.forEach { tipo ->
                        BotonCategoria(
                            tipo = tipo,
                            onClick = { onCategoria(tipo) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            TarjetaRutaInnovacion(onClick = { onCategoria(TipoContenido.PROYECTO) })

            AnimatedVisibility(
                visible = historial.isNotEmpty(),
                enter = fadeIn() + expandVertically()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Consultados recientemente",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    historial.forEach { contenido ->
                        TarjetaContenido(
                            contenido = contenido,
                            onClick = { onAbrir(contenido.idContenido) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun BotonCategoria(tipo: TipoContenido, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val fuente = remember { MutableInteractionSource() }
    Card(
        onClick = onClick,
        interactionSource = fuente,
        modifier = modifier.escalaAlPresionar(fuente),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = tipo.icono(),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Text(
                text = tipo.plural,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
private fun TarjetaRutaInnovacion(onClick: () -> Unit) {
    val fuente = remember { MutableInteractionSource() }
    Card(
        onClick = onClick,
        interactionSource = fuente,
        modifier = Modifier
            .fillMaxWidth()
            .escalaAlPresionar(fuente),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary
            )
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    text = "Ruta de Innovación",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Text(
                    text = "Descubre contenidos relacionados",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}
