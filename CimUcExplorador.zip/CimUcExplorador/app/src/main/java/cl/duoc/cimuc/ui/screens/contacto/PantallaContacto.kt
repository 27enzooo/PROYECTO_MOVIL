@file:OptIn(ExperimentalMaterial3Api::class)

package cl.duoc.cimuc.ui.screens.contacto

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cl.duoc.cimuc.recursos.NotificacionHelper
import cl.duoc.cimuc.recursos.VibradorHelper
import cl.duoc.cimuc.ui.components.BarraSuperior
import cl.duoc.cimuc.ui.components.BotonPrincipal
import cl.duoc.cimuc.ui.components.CampoValidado
import cl.duoc.cimuc.ui.theme.ColorExito
import cl.duoc.cimuc.validacion.Validadores

@Composable
fun PantallaContacto(
    viewModel: ContactoViewModel,
    onVolver: () -> Unit
) {
    val estado by viewModel.estado.collectAsStateWithLifecycle()
    val contexto = LocalContext.current

    // Se pide el permiso de notificaciones solo cuando el formulario ya es válido.
    // Si el usuario lo rechaza, la solicitud igualmente se registra, sin notificación.
    val lanzadorPermiso = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> viewModel.enviar() }

    LaunchedEffect(estado.enviado) {
        if (estado.enviado) {
            VibradorHelper.exito(contexto)
            NotificacionHelper.mostrar(
                context = contexto,
                titulo = "Solicitud enviada (simulación)",
                texto = estado.oportunidad?.titulo ?: "Colaboración con CIM UC"
            )
        }
    }

    Scaffold(topBar = { BarraSuperior("Colaboración", onVolver) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .imePadding()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "¿Te interesa colaborar?",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            estado.oportunidad?.let { oportunidad ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "OPORTUNIDAD",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = oportunidad.titulo,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = oportunidad.descripcion,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            CampoValidado(
                valor = estado.organizacion.valor,
                onCambio = viewModel::onOrganizacionChange,
                etiqueta = "Organización",
                iconoPrincipal = Icons.Filled.Business,
                error = estado.organizacion.error,
                valido = estado.organizacion.valido,
                maxCaracteres = Validadores.MAX_ORGANIZACION,
                habilitado = !estado.enviado
            )

            CampoValidado(
                valor = estado.mensaje.valor,
                onCambio = viewModel::onMensajeChange,
                etiqueta = "Mensaje",
                iconoPrincipal = Icons.Filled.Edit,
                error = estado.mensaje.error,
                valido = estado.mensaje.valido,
                maxCaracteres = Validadores.MAX_MENSAJE,
                lineasMinimas = 4,
                habilitado = !estado.enviado
            )

            BotonPrincipal(
                texto = if (estado.enviado) "Solicitud enviada" else "Enviar solicitud",
                icono = Icons.AutoMirrored.Filled.Send,
                habilitado = !estado.enviado,
                onClick = {
                    if (viewModel.validarTodo()) {
                        if (NotificacionHelper.tienePermiso(contexto)) {
                            viewModel.enviar()
                        } else {
                            lanzadorPermiso.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    } else {
                        VibradorHelper.error(contexto)
                    }
                }
            )

            AnimatedVisibility(
                visible = estado.enviado,
                enter = fadeIn() + scaleIn() + expandVertically()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = ColorExito
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = "Solicitud registrada en el dispositivo. No se envió información a ningún sistema real.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.padding(bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = ColorExito
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Simulación académica",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
