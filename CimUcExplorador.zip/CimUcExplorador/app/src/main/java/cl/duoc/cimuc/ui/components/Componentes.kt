@file:OptIn(ExperimentalMaterial3Api::class)

package cl.duoc.cimuc.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import cl.duoc.cimuc.data.local.Contenido
import cl.duoc.cimuc.data.model.TipoContenido
import cl.duoc.cimuc.ui.theme.ColorExito
import kotlinx.coroutines.delay

fun TipoContenido.icono(): ImageVector = when (this) {
    TipoContenido.PROYECTO -> Icons.Filled.Folder
    TipoContenido.CAPACIDAD -> Icons.Filled.Build
    TipoContenido.INTEGRANTE -> Icons.Filled.Person
    TipoContenido.PUBLICACION -> Icons.Filled.Description
    TipoContenido.ACTIVIDAD -> Icons.Filled.Event
}

/** Animación de retroalimentación: el elemento se reduce levemente mientras se presiona. */
@Composable
fun Modifier.escalaAlPresionar(fuente: InteractionSource): Modifier {
    val presionado by fuente.collectIsPressedAsState()
    val escala by animateFloatAsState(
        targetValue = if (presionado) 0.96f else 1f,
        animationSpec = tween(120),
        label = "escala"
    )
    return this.graphicsLayer {
        scaleX = escala
        scaleY = escala
    }
}

/** Animación de entrada escalonada (fundido + desplazamiento) según la posición del elemento. */
@Composable
fun AparicionEscalonada(indice: Int, contenido: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(indice * 140L)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 3 }
    ) {
        contenido()
    }
}

@Composable
fun BarraSuperior(titulo: String, onVolver: () -> Unit) {
    TopAppBar(
        title = { Text(titulo) },
        navigationIcon = {
            IconButton(onClick = onVolver) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
    )
}

@Composable
fun TarjetaContenido(contenido: Contenido, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val fuente = remember { MutableInteractionSource() }
    Card(
        onClick = onClick,
        interactionSource = fuente,
        modifier = modifier
            .fillMaxWidth()
            .escalaAlPresionar(fuente),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = contenido.tipo.icono(),
                contentDescription = contenido.tipo.singular,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    text = contenido.titulo,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${contenido.tipo.singular} · ${contenido.area} · ${contenido.anio}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun BotonPrincipal(
    texto: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icono: ImageVector? = null,
    habilitado: Boolean = true
) {
    val fuente = remember { MutableInteractionSource() }
    Button(
        onClick = onClick,
        enabled = habilitado,
        interactionSource = fuente,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .escalaAlPresionar(fuente)
    ) {
        if (icono != null) {
            Icon(icono, contentDescription = null)
            Spacer(Modifier.width(8.dp))
        }
        Text(texto)
    }
}

@Composable
fun BotonSecundario(texto: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val fuente = remember { MutableInteractionSource() }
    OutlinedButton(
        onClick = onClick,
        interactionSource = fuente,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .escalaAlPresionar(fuente)
    ) {
        Text(texto)
    }
}

/** Campo de formulario con ícono, retroalimentación visual animada y mensaje de error. */
@Composable
fun CampoValidado(
    valor: String,
    onCambio: (String) -> Unit,
    etiqueta: String,
    iconoPrincipal: ImageVector,
    error: String?,
    valido: Boolean,
    modifier: Modifier = Modifier,
    maxCaracteres: Int? = null,
    lineasMinimas: Int = 1,
    habilitado: Boolean = true
) {
    val colorBorde by animateColorAsState(
        targetValue = when {
            error != null -> MaterialTheme.colorScheme.error
            valido -> ColorExito
            else -> MaterialTheme.colorScheme.outline
        },
        label = "colorBorde"
    )
    OutlinedTextField(
        value = valor,
        onValueChange = onCambio,
        modifier = modifier.fillMaxWidth(),
        enabled = habilitado,
        label = { Text(etiqueta) },
        leadingIcon = { Icon(iconoPrincipal, contentDescription = null) },
        trailingIcon = {
            val estadoIcono = when {
                error != null -> 1
                valido -> 2
                else -> 0
            }
            Crossfade(targetState = estadoIcono, label = "iconoEstado") { estado ->
                when (estado) {
                    1 -> Icon(
                        Icons.Filled.Error,
                        contentDescription = "Campo con error",
                        tint = MaterialTheme.colorScheme.error
                    )
                    2 -> Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = "Campo válido",
                        tint = ColorExito
                    )
                    else -> Spacer(Modifier.size(24.dp))
                }
            }
        },
        isError = error != null,
        supportingText = {
            AnimatedContent(targetState = error, label = "mensajeError") { mensaje ->
                if (mensaje != null) {
                    Text(mensaje)
                } else if (maxCaracteres != null) {
                    Text("${valor.length}/$maxCaracteres")
                } else {
                    Text("")
                }
            }
        },
        singleLine = lineasMinimas == 1,
        minLines = lineasMinimas,
        keyboardOptions = KeyboardOptions.Default,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colorBorde,
            unfocusedBorderColor = colorBorde,
            errorBorderColor = colorBorde
        )
    )
}

@Composable
fun SelectorFiltro(
    etiqueta: String,
    seleccion: String,
    opciones: List<String>,
    onSeleccion: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var abierto by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { abierto = true }, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "$etiqueta: $seleccion",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = abierto, onDismissRequest = { abierto = false }) {
            opciones.forEachIndexed { indice, opcion ->
                DropdownMenuItem(
                    text = { Text(opcion) },
                    onClick = {
                        abierto = false
                        onSeleccion(indice)
                    }
                )
            }
        }
    }
}
