package cl.duoc.cimuc.data.model

import cl.duoc.cimuc.data.local.Contenido
import cl.duoc.cimuc.data.local.Oportunidad

/** Un paso de la cadena Proyecto → Capacidad I+D → Integrante → Oportunidad. */
data class PasoRuta(
    val etiqueta: String,
    val titulo: String?,
    val detalle: String?,
    val idContenido: Int?,
    val esActual: Boolean,
    val esOportunidad: Boolean = false
)

data class RutaInnovacion(
    val origen: Contenido,
    val pasos: List<PasoRuta>,
    val relacionados: List<Contenido>,
    val oportunidad: Oportunidad?
) {
    /** Primer paso disponible posterior al contenido consultado. */
    val siguiente: PasoRuta?
        get() {
            val indiceActual = pasos.indexOfFirst { it.esActual }
            return pasos.drop(indiceActual + 1).firstOrNull { it.titulo != null }
        }
}
