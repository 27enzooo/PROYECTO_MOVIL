package cl.duoc.cimuc.ui.screens.contacto

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.duoc.cimuc.data.local.Oportunidad
import cl.duoc.cimuc.data.repository.ContenidoRepository
import cl.duoc.cimuc.validacion.Validadores
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CampoUi(
    val valor: String = "",
    val error: String? = null,
    val tocado: Boolean = false
) {
    val valido: Boolean get() = tocado && error == null
}

data class ContactoUiState(
    val organizacion: CampoUi = CampoUi(),
    val mensaje: CampoUi = CampoUi(),
    val oportunidad: Oportunidad? = null,
    val enviado: Boolean = false
)

class ContactoViewModel(
    savedStateHandle: SavedStateHandle,
    private val repositorio: ContenidoRepository
) : ViewModel() {

    private val idContenido: Int = checkNotNull(savedStateHandle["id"])

    private val _estado = MutableStateFlow(ContactoUiState())
    val estado: StateFlow<ContactoUiState> = _estado.asStateFlow()

    init {
        viewModelScope.launch {
            val oportunidad = repositorio.construirRuta(idContenido)?.oportunidad
            _estado.update { it.copy(oportunidad = oportunidad) }
        }
    }

    fun onOrganizacionChange(valor: String) = _estado.update {
        it.copy(organizacion = CampoUi(valor, Validadores.organizacion(valor), tocado = true), enviado = false)
    }

    fun onMensajeChange(valor: String) = _estado.update {
        it.copy(mensaje = CampoUi(valor, Validadores.mensaje(valor), tocado = true), enviado = false)
    }

    /** Valida todos los campos, deja visibles los errores y devuelve true si el formulario es correcto. */
    fun validarTodo(): Boolean {
        val actual = _estado.value
        val organizacion = CampoUi(actual.organizacion.valor, Validadores.organizacion(actual.organizacion.valor), true)
        val mensaje = CampoUi(actual.mensaje.valor, Validadores.mensaje(actual.mensaje.valor), true)
        _estado.update { it.copy(organizacion = organizacion, mensaje = mensaje) }
        return organizacion.error == null && mensaje.error == null
    }

    fun enviar() {
        val actual = _estado.value
        if (actual.enviado) return
        viewModelScope.launch {
            repositorio.guardarSolicitud(
                idContenido = idContenido,
                organizacion = actual.organizacion.valor.trim(),
                mensaje = actual.mensaje.valor.trim()
            )
            _estado.update { it.copy(enviado = true) }
        }
    }
}
