package cl.duoc.cimuc.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import cl.duoc.cimuc.data.model.TipoContenido
import kotlinx.coroutines.flow.Flow

@Dao
interface CimDao {

    @Query("SELECT COUNT(*) FROM contenido")
    suspend fun contarContenidos(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarContenidos(lista: List<Contenido>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarRelaciones(lista: List<Relacion>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarOportunidades(lista: List<Oportunidad>)

    @Insert
    suspend fun insertarSolicitud(solicitud: Solicitud)

    @Query(
        """
        SELECT * FROM contenido
        WHERE (:tipo IS NULL OR tipo = :tipo)
          AND (:area IS NULL OR area = :area)
          AND (:texto = '' OR titulo LIKE '%' || :texto || '%' OR descripcion LIKE '%' || :texto || '%')
        ORDER BY titulo
        """
    )
    fun buscar(texto: String, tipo: TipoContenido?, area: String?): Flow<List<Contenido>>

    @Query("SELECT DISTINCT area FROM contenido ORDER BY area")
    fun areas(): Flow<List<String>>

    @Query("SELECT * FROM contenido WHERE idContenido = :id")
    suspend fun obtener(id: Int): Contenido?

    @Query(
        """
        SELECT DISTINCT c.* FROM contenido c
        INNER JOIN relacion r
          ON (r.contenidoDestino = c.idContenido AND r.contenidoOrigen = :id)
          OR (r.contenidoOrigen = c.idContenido AND r.contenidoDestino = :id)
        ORDER BY c.idContenido
        """
    )
    suspend fun relacionados(id: Int): List<Contenido>

    @Query("SELECT * FROM oportunidad WHERE idContenido = :id LIMIT 1")
    suspend fun oportunidadDe(id: Int): Oportunidad?
}
