package cl.duoc.cimuc

import android.app.Application
import cl.duoc.cimuc.data.local.AppDatabase
import cl.duoc.cimuc.data.repository.ContenidoRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CimApplication : Application() {

    private val database by lazy { AppDatabase.obtener(this) }
    val repository by lazy { ContenidoRepository(database.dao()) }

    override fun onCreate() {
        super.onCreate()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            repository.cargarDatosIniciales()
        }
    }
}
