package cl.duoc.cimuc.ui.screens.busqueda

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.duoc.cimuc.data.local.Contenido
import cl.duoc.cimuc.data.model.TipoContenido
import cl.duoc.cimuc.data.repository.ContenidoRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

data class FiltrosUi(
    val texto: String = "",
    val tipo: TipoContenido? = null,
    val area: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class BusquedaViewModel(
    savedStateHandle: SavedStateHandle,
    repositorio: ContenidoRepository
) : ViewModel() {

    private val tipoInicial: TipoContenido? =
        savedStateHandle.get<String>("tipo")?.let { nombre ->
            TipoContenido.entries.firstOrNull { it.name == nombre }
        }

    private val _filtros = MutableStateFlow(FiltrosUi(tipo = tipoInicial))
    val filtros: StateFlow<FiltrosUi> = _filtros.asStateFlow()

    val areas: StateFlow<List<String>> = repositorio.areas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val resultados: StateFlow<List<Contenido>> = _filtros
        .flatMapLatest { repositorio.buscar(it.texto.trim(), it.tipo, it.area) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun onTextoChange(texto: String) = _filtros.update { it.copy(texto = texto) }
    fun onTipoChange(tipo: TipoContenido?) = _filtros.update { it.copy(tipo = tipo) }
    fun onAreaChange(area: String?) = _filtros.update { it.copy(area = area) }
}
