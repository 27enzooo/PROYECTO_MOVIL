package cl.duoc.cimuc.data.repository

import cl.duoc.cimuc.data.local.CimDao
import cl.duoc.cimuc.data.local.Contenido
import cl.duoc.cimuc.data.local.DatosIniciales
import cl.duoc.cimuc.data.local.Oportunidad
import cl.duoc.cimuc.data.local.Solicitud
import cl.duoc.cimuc.data.model.PasoRuta
import cl.duoc.cimuc.data.model.RutaInnovacion
import cl.duoc.cimuc.data.model.TipoContenido
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ContenidoRepository(private val dao: CimDao) {

    // Historial básico (RF-08): últimos contenidos consultados durante la sesión.
    private val _historial = MutableStateFlow<List<Contenido>>(emptyList())
    val historial: StateFlow<List<Contenido>> = _historial.asStateFlow()

    suspend fun cargarDatosIniciales() {
        if (dao.contarContenidos() == 0) {
            dao.insertarContenidos(DatosIniciales.contenidos)
            dao.insertarRelaciones(DatosIniciales.relaciones)
            dao.insertarOportunidades(DatosIniciales.oportunidades)
        }
    }

    fun buscar(texto: String, tipo: TipoContenido?, area: String?): Flow<List<Contenido>> =
        dao.buscar(texto, tipo, area)

    fun areas(): Flow<List<String>> = dao.areas()

    suspend fun obtener(id: Int): Contenido? = dao.obtener(id)

    suspend fun relacionados(id: Int): List<Contenido> = dao.relacionados(id)

    fun registrarConsulta(contenido: Contenido) {
        _historial.value = (listOf(contenido) + _historial.value.filter { it.idContenido != contenido.idContenido })
            .take(MAX_HISTORIAL)
    }

    /** Construye la Ruta de Innovación a partir del contenido consultado. */
    suspend fun construirRuta(id: Int): RutaInnovacion? {
        val origen = dao.obtener(id) ?: return null
        val directos = dao.relacionados(id)
        val indirectos = directos
            .flatMap { dao.relacionados(it.idContenido) }
            .filter { it.idContenido != id }
        val candidatos = (directos + indirectos).distinctBy { it.idContenido }

        fun elegir(tipo: TipoContenido): Contenido? =
            if (origen.tipo == tipo) origen else candidatos.firstOrNull { it.tipo == tipo }

        val proyecto = elegir(TipoContenido.PROYECTO)
        val capacidad = elegir(TipoContenido.CAPACIDAD)
        val integrante = elegir(TipoContenido.INTEGRANTE)
        val elegidos = listOfNotNull(proyecto, capacidad, integrante)

        val oportunidad: Oportunidad? = (listOf(origen) + elegidos)
            .firstNotNullOfOrNull { dao.oportunidadDe(it.idContenido) }

        fun paso(etiqueta: String, contenido: Contenido?) = PasoRuta(
            etiqueta = etiqueta,
            titulo = contenido?.titulo,
            detalle = contenido?.area,
            idContenido = contenido?.idContenido,
            esActual = contenido?.idContenido == id
        )

        val pasos = listOf(
            paso("PROYECTO", proyecto),
            paso("CAPACIDAD I+D", capacidad),
            paso("INTEGRANTE", integrante),
            PasoRuta(
                etiqueta = "OPORTUNIDAD",
                titulo = oportunidad?.titulo,
                detalle = oportunidad?.descripcion,
                idContenido = null,
                esActual = false,
                esOportunidad = true
            )
        )

        val usados = elegidos.map { it.idContenido } + id
        val relacionados = candidatos.filter { it.idContenido !in usados }.take(MAX_RELACIONADOS)

        return RutaInnovacion(origen, pasos, relacionados, oportunidad)
    }

    suspend fun guardarSolicitud(idContenido: Int, organizacion: String, mensaje: String) {
        dao.insertarSolicitud(
            Solicitud(
                idContenido = idContenido,
                organizacion = organizacion,
                mensaje = mensaje,
                fecha = System.currentTimeMillis()
            )
        )
    }

    private companion object {
        const val MAX_HISTORIAL = 5
        const val MAX_RELACIONADOS = 4
    }
}
