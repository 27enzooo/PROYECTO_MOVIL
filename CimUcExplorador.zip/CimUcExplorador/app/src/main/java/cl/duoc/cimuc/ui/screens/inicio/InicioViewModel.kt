package cl.duoc.cimuc.ui.screens.inicio

import androidx.lifecycle.ViewModel
import cl.duoc.cimuc.data.local.Contenido
import cl.duoc.cimuc.data.repository.ContenidoRepository
import kotlinx.coroutines.flow.StateFlow

class InicioViewModel(repositorio: ContenidoRepository) : ViewModel() {
    val historial: StateFlow<List<Contenido>> = repositorio.historial
}
