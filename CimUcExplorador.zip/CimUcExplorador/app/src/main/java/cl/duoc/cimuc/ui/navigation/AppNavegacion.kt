package cl.duoc.cimuc.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import cl.duoc.cimuc.data.model.TipoContenido
import cl.duoc.cimuc.ui.AppViewModelProvider
import cl.duoc.cimuc.ui.screens.busqueda.BusquedaViewModel
import cl.duoc.cimuc.ui.screens.busqueda.PantallaBusqueda
import cl.duoc.cimuc.ui.screens.contacto.ContactoViewModel
import cl.duoc.cimuc.ui.screens.contacto.PantallaContacto
import cl.duoc.cimuc.ui.screens.detalle.DetalleViewModel
import cl.duoc.cimuc.ui.screens.detalle.PantallaDetalle
import cl.duoc.cimuc.ui.screens.inicio.InicioViewModel
import cl.duoc.cimuc.ui.screens.inicio.PantallaInicio
import cl.duoc.cimuc.ui.screens.ruta.PantallaRuta
import cl.duoc.cimuc.ui.screens.ruta.RutaViewModel

object Rutas {
    const val INICIO = "inicio"
    const val BUSQUEDA = "busqueda?tipo={tipo}"
    const val DETALLE = "detalle/{id}"
    const val RUTA = "ruta/{id}"
    const val CONTACTO = "contacto/{id}"

    fun busqueda(tipo: TipoContenido? = null) =
        if (tipo == null) "busqueda" else "busqueda?tipo=${tipo.name}"

    fun detalle(id: Int) = "detalle/$id"
    fun ruta(id: Int) = "ruta/$id"
    fun contacto(id: Int) = "contacto/$id"
}

@Composable
fun AppNavegacion() {
    val nav = rememberNavController()
    val argumentoId = listOf(navArgument("id") { type = NavType.IntType })

    NavHost(
        navController = nav,
        startDestination = Rutas.INICIO,
        enterTransition = { slideInHorizontally(tween(300)) { it } + fadeIn(tween(300)) },
        exitTransition = { slideOutHorizontally(tween(300)) { -it / 4 } + fadeOut(tween(300)) },
        popEnterTransition = { slideInHorizontally(tween(300)) { -it / 4 } + fadeIn(tween(300)) },
        popExitTransition = { slideOutHorizontally(tween(300)) { it } + fadeOut(tween(300)) }
    ) {
        composable(Rutas.INICIO) {
            val viewModel: InicioViewModel = viewModel(factory = AppViewModelProvider.Factory)
            PantallaInicio(
                viewModel = viewModel,
                onBuscar = { nav.navigate(Rutas.busqueda()) },
                onCategoria = { tipo -> nav.navigate(Rutas.busqueda(tipo)) },
                onAbrir = { id -> nav.navigate(Rutas.detalle(id)) }
            )
        }

        composable(
            route = Rutas.BUSQUEDA,
            arguments = listOf(
                navArgument("tipo") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) {
            val viewModel: BusquedaViewModel = viewModel(factory = AppViewModelProvider.Factory)
            PantallaBusqueda(
                viewModel = viewModel,
                onVolver = { nav.popBackStack() },
                onAbrir = { id -> nav.navigate(Rutas.detalle(id)) }
            )
        }

        composable(route = Rutas.DETALLE, arguments = argumentoId) {
            val viewModel: DetalleViewModel = viewModel(factory = AppViewModelProvider.Factory)
            PantallaDetalle(
                viewModel = viewModel,
                onVolver = { nav.popBackStack() },
                onVerRuta = { id -> nav.navigate(Rutas.ruta(id)) },
                onColaborar = { id -> nav.navigate(Rutas.contacto(id)) },
                onAbrir = { id -> nav.navigate(Rutas.detalle(id)) }
            )
        }

        composable(route = Rutas.RUTA, arguments = argumentoId) {
            val viewModel: RutaViewModel = viewModel(factory = AppViewModelProvider.Factory)
            PantallaRuta(
                viewModel = viewModel,
                onVolver = { nav.popBackStack() },
                onAbrir = { id -> nav.navigate(Rutas.detalle(id)) },
                onColaborar = { id -> nav.navigate(Rutas.contacto(id)) }
            )
        }

        composable(route = Rutas.CONTACTO, arguments = argumentoId) {
            val viewModel: ContactoViewModel = viewModel(factory = AppViewModelProvider.Factory)
            PantallaContacto(
                viewModel = viewModel,
                onVolver = { nav.popBackStack() }
            )
        }
    }
}
