package cl.duoc.cimuc.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import cl.duoc.cimuc.data.model.TipoContenido

/** Entidad base: proyectos, capacidades, integrantes, publicaciones y actividades. */
@Entity(tableName = "contenido")
data class Contenido(
    @PrimaryKey val idContenido: Int,
    val titulo: String,
    val descripcion: String,
    val tipo: TipoContenido,
    val area: String,
    val anio: Int,
    val estado: String,
    val imagen: String
)

@Entity(tableName = "relacion")
data class Relacion(
    @PrimaryKey(autoGenerate = true) val idRelacion: Int = 0,
    val contenidoOrigen: Int,
    val contenidoDestino: Int,
    val tipoRelacion: String
)

@Entity(tableName = "oportunidad")
data class Oportunidad(
    @PrimaryKey val idOportunidad: Int,
    val titulo: String,
    val descripcion: String,
    val contactoSimulado: String,
    val idContenido: Int
)

/** Solicitud de colaboración simulada, guardada solo en el dispositivo. */
@Entity(tableName = "solicitud")
data class Solicitud(
    @PrimaryKey(autoGenerate = true) val idSolicitud: Int = 0,
    val idContenido: Int,
    val organizacion: String,
    val mensaje: String,
    val fecha: Long
)
