package cl.duoc.cimuc.ui.screens.detalle

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.duoc.cimuc.data.local.Contenido
import cl.duoc.cimuc.data.repository.ContenidoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DetalleViewModel(
    savedStateHandle: SavedStateHandle,
    private val repositorio: ContenidoRepository
) : ViewModel() {

    private val id: Int = checkNotNull(savedStateHandle["id"])

    private val _contenido = MutableStateFlow<Contenido?>(null)
    val contenido: StateFlow<Contenido?> = _contenido.asStateFlow()

    private val _relacionados = MutableStateFlow<List<Contenido>>(emptyList())
    val relacionados: StateFlow<List<Contenido>> = _relacionados.asStateFlow()

    init {
        viewModelScope.launch {
            val encontrado = repositorio.obtener(id)
            _contenido.value = encontrado
            if (encontrado != null) {
                repositorio.registrarConsulta(encontrado)
                _relacionados.value = repositorio.relacionados(id)
            }
        }
    }
}
