package cl.duoc.cimuc.recursos

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Recurso nativo: vibración del dispositivo (retroalimentación háptica del formulario). */
object VibradorHelper {

    fun exito(context: Context) = vibrar(context, VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))

    fun error(context: Context) =
        vibrar(context, VibrationEffect.createWaveform(longArrayOf(0, 70, 60, 70), -1))

    private fun vibrar(context: Context, efecto: VibrationEffect) {
        val vibrador: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (vibrador != null && vibrador.hasVibrator()) {
            vibrador.vibrate(efecto)
        }
    }
}
